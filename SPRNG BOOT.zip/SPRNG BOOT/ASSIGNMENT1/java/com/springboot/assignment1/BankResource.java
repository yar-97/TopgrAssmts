package com.springboot.assignment1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.ipc.http.HttpSender.Method;

@RestController
public class BankResource {
	
	@RequestMapping("/bankname")
	public String getName()
	{
		return "HDFC BANK";
	}
	
	@RequestMapping("/bankaddr")
	public String getAddress()
	{
		return "ELECTRONIC CITY,BANGALORE";
	}
	
	

}
