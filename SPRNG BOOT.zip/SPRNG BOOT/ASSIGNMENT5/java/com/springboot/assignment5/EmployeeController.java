package com.springboot.assignment5;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springboot.assignment5.Employee;
import com.springboot.assignment5.EmployeeDao;
import com.springboot.assignment5.EmployeeService;



@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService s;
	
	@RequestMapping(value="/displayAll",method=RequestMethod.GET)
	@ResponseBody
	public List<Employee> getAllUsers()
	{
		List<Employee> l= s.getAllUsers();
		return l;
	}
	
	
	@RequestMapping(value="/getspecificemployee/{id}",method=RequestMethod.GET) 
	@ResponseBody
	public Employee specificEmployee(@PathVariable("id") int id)
	{
		Employee e=s.specificEmployee(id);
		
		return e;
	}
	
	
	@RequestMapping(value="/newemployee",method=RequestMethod.POST)
	@ResponseBody
	public Employee newemp(@ModelAttribute("empid") int id,@ModelAttribute("Name") String name,
							@ModelAttribute("E-mail") String email,@ModelAttribute("location") String loc)
	{
		Employee e =new Employee(id,name,email,loc);
		Employee e1=s.newemp(e);
		return e1;
	}

	@RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
	@ResponseBody
	public Employee updatedetails(Employee e)
	{
		Employee e1=s.updatedetails(e);
		return e1;
	}
	
	@RequestMapping(value = "/deleteemp/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public Employee deletemp(@PathVariable("id") int id)
	{
		Employee e=s.deletemp(id);
		return e;
	}
	

}
	
	
	
	
	
