package com.springboot.assignment5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import com.springboot.assignment5.*;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDao d;
	
	public List<Employee> getAllUsers()
	{
		List<Employee> l=d.getAllUsers();
		return l;
	}
	
	public Employee specificEmployee(int id)
	{
		Employee e=d.specificEmployee(id);
		return e;
	}
	
	public Employee newemp(Employee e)
	{
		Employee e1=d.newemp(e);
		return e1;
	}
	
	public Employee updatedetails(Employee e)
	{
		Employee e1=d.updatedetails(e);
		return e1;
	}
	public Employee deletemp(int id)
	{
		Employee e=d.deleteemp(id);
		return e;
	}

}
