package com.springboot.assignment5;

public class Employee {
	
	private int empID;
	private String empName;
	private String email;
	private String location;
	
	public Employee(int eid,String ename,String email,String loc)
	{
			this.empID=eid;
			this.empName=ename;
			this.email=email;
			this.location=loc;
	}
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
