package com.springboot.assignment5;
import java.util.*;

import org.springframework.stereotype.Repository;
import com.springboot.assignment5.Employee;

@Repository
public class EmployeeDao {
	
	static HashMap<Integer,Employee> m=new HashMap<Integer,Employee>();
	
	public EmployeeDao()
	{
		Employee e =new Employee(1001,"Surya Pratap","surya.pratap@company.com","Jhansi");
		Employee e1 =new Employee(1002,"Shashwat Yadav","shashwat.yadav@company.com","Lucknow");
		Employee e2 =new Employee(1003,"Sarthak Tyagi","sarthak.tyagi@company.com","Noida");
		
		m.put(1001, e);m.put(1002, e1);m.put(1003, e2);
		
	}
	
	public List<Employee> getAllUsers()
	{
		List<Employee> l=new ArrayList<Employee>(m.values());
		
		return l;
	}
	
	public Employee specificEmployee(int id)
	{
		Employee e=m.get(id);
		return e;
	}
	
	public Employee newemp(Employee e)
	{
		m.put(e.getEmpID(), e);
		return m.get(e.getEmpID());
	}
	
	public Employee updatedetails(Employee e)
	{
		if(m.get(e.getEmpID())!=null)
		{
			m.put(e.getEmpID(), e);
		}
		else
		{
			m.put(e.getEmpID(), e);
		}
		
		return e;
	}
	
	public Employee deleteemp(int id)
	{
		Employee e1=m.remove(id);
		return e1;
	}
	

}
