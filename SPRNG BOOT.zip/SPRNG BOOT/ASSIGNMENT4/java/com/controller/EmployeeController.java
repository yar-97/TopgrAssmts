package com.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.EmployeeDb;
import com.model.EmployeeRepository;

@RestController
@Service
public class EmployeeController {

	@Autowired
	private EmployeeRepository emprepo;
	
	
	@RequestMapping(method=RequestMethod.GET,value="/displayall",produces="application/json")
	public Iterable<EmployeeDb> getAllEmployees()
	{
		return emprepo.findAll();
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/display/{id}" ,produces="application/json")
	public Optional<EmployeeDb> getEmpiddetails(@PathVariable("id") long id)
	{
		return emprepo.findById(id);
	}

	@RequestMapping(method = RequestMethod.POST , value = "/addemp" , produces="application/json")
	public void addEmployee(@ModelAttribute("eid") long eid,@ModelAttribute("name") String name,@ModelAttribute("mail") String mail,@ModelAttribute("location") String location)
	{
		EmployeeDb add = new EmployeeDb(eid,name,mail,location);
		emprepo.save(add);

	}
}
