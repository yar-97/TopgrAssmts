package com.springboot.assignment4;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.model.EmployeeDb;
import com.model.EmployeeRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.model")
@EntityScan(basePackages = "com.model")
@ComponentScan(basePackages = "com.controller")

public class Assignment4Application {

	/*
	 * @Autowired private EmployeeRepository emp;
	 */
	public static void main(String[] args) {
		SpringApplication.run(Assignment4Application.class, args);
	}

	/*
	 * @PostConstruct public void init() { System.out.println("INSIDE SAVED");
	 * 
	 * EmployeeDb e1 = new EmployeeDb((long) 999, "Aravind", "aravind@gmail.com",
	 * "Kurnool"); EmployeeDb e2 = new EmployeeDb((long) 888, "Vishnu",
	 * "vishnu@gmail.com", "Bangalore");
	 * 
	 * List<EmployeeDb> emps = new ArrayList<EmployeeDb>(); emps.add(e1);
	 * emps.add(e2);
	 * 
	 * System.out.println("BEFORE SAVED");
	 * 
	 * emp.saveAll(emps);
	 * 
	 * System.out.println("SAVED"); }
	 */

}
