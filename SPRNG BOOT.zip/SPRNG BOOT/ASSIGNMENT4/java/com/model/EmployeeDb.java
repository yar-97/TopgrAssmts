package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EmployeeDb")
public class EmployeeDb {

	@Id
	
	Long empid;
	String ename,email,loc;
	
	public EmployeeDb()
	{
		
	}
	
	
	public EmployeeDb(Long empid, String ename, String email, String loc) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.email = email;
		this.loc = loc;
	}
	public Long getEmpid() {
		return empid;
	}
	public void setEmpid(Long empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}


	@Override
	public String toString() {
		return "EmployeeDb [empid=" + empid + ", ename=" + ename + ", email=" + email + ", loc=" + loc + "]";
	}
	
	
	
}
