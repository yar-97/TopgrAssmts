package com.springboot.assignment2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Resource {
	
	@RequestMapping("/bname")
	public ModelAndView getName() 
	{
		ModelAndView mv = new ModelAndView();
		mv.addObject("branch","EC");
		mv.addObject("city","Banglore");
		mv.addObject("branch","Kodathi");
		mv.addObject("city","Banglore");
		mv.addObject("branch","slikboard");
		mv.addObject("city","Banglore");
		mv.setViewName("bname");
		return mv;
	}
	
	@RequestMapping("/service")
	public String getServices()
	{
		return "service";
	}
	
	
	

}
